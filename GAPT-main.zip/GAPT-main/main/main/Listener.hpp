#ifndef LISTENER_HPP
#define LISTENER_HPP

#include <string>

// Function to listen for the server's broadcasted IP
void listenForServerIP();

#endif // LISTENER_HPP
