#ifndef DRAGBLOCK_HPP
#define DRAGBLOCK_HPP

#include <SDL3/SDL.h>
#include "Tetromino.hpp"

void DragDrop(SDL_Event& event);


#endif