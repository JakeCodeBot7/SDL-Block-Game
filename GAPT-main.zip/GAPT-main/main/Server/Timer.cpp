#include "Timer.hpp"
#include <iostream>

void GameOverAction() {
    std::cout << "Time's up! The game is over!" << std::endl;
    // Additional game-over logic can go here.
}